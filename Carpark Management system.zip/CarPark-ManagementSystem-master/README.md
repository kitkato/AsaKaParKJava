# CarPark-ManagementSystem
This repository contains a car park management system which I have developed to improve my Java OOP skills. This system has the ability to maintain 20 parking slots as well as system has implemented to maintain three major vehicle types such as Cars, Vans, Motorbikes.

 
