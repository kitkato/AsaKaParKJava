OOP CW01 by Dilum De Silva(2016142)
This folder contains the diagrams related to this program which I have drawn using draw.io
